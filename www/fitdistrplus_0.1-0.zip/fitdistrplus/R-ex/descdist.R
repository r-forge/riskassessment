### Name: descdist
### Title: Description of an empirical distribution for non-censored data
### Aliases: descdist
### Keywords: distribution

### ** Examples

x1<-c(6.4,13.3,4.1,1.3,14.1,10.6,9.9,9.6,15.3,22.1,13.4,
13.2,8.4,6.3,8.9,5.2,10.9,14.4)
descdist(x1)
descdist(x1,boot=1000)

x2<-c(rep(4,1),rep(2,3),rep(1,7),rep(0,12))
descdist(x2,discrete=TRUE)

x3<-rbeta(100,shape1=0.05,shape2=1)
descdist(x3,boot=1000)



