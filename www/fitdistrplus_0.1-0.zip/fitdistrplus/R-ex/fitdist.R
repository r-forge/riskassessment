### Name: fitdist
### Title: Fitting of univariate distributions to non-censored data and
###   goodness-of-fit statistics
### Aliases: fitdist plot.fitdist print.fitdist summary.fitdist
###   fitdistrplus
### Keywords: distribution

### ** Examples

x1<-c(6.4,13.3,4.1,1.3,14.1,10.6,9.9,9.6,15.3,22.1,13.4,
13.2,8.4,6.3,8.9,5.2,10.9,14.4)
f1<-fitdist(x1,"norm")
print(f1)
plot(f1)
summary(f1)
f1$chisqtable

f1b<-fitdist(x1,"norm",method="mom",meancount=6)
summary(f1b)
f1b$chisqtable

f1c<-fitdist(x1,"lnorm",method="mom",meancount=6)
summary(f1c)
f1c$chisqtable

dgumbel<-function(x,a,b) 1/b*exp((a-x)/b)*exp(-exp((a-x)/b))
pgumbel<-function(q,a,b) exp(-exp((a-q)/b))
qgumbel<-function(p,a,b) a-b*log(-log(p))
f1c<-fitdist(x1,"gumbel",start=list(a=10,b=5))
print(f1c)
plot(f1c)

x2<-c(rep(4,1),rep(2,3),rep(1,7),rep(0,12))
f2<-fitdist(x2,"pois",chisqbreaks=c(0,1))
plot(f2)
summary(f2)
f2$chisqtable

xw<-rweibull(n=100,shape=2,scale=1)
fa<-fitdist(xw,"weibull")
summary(fa)
fa$chisqtable
fb<-fitdist(xw,"gamma")
summary(fb)
fc<-fitdist(xw,"exp")
summary(fc)




