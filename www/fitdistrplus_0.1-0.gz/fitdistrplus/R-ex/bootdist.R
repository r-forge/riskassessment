### Name: bootdist
### Title: Bootstrap simulation of uncertainty for non-censored data
### Aliases: bootdist plot.bootdist print.bootdist summary.bootdist
### Keywords: distribution

### ** Examples

x1<-c(6.4,13.3,4.1,1.3,14.1,10.6,9.9,9.6,15.3,22.1,13.4,
13.2,8.4,6.3,8.9,5.2,10.9,14.4)

f1<-fitdist(x1,"norm",method="mle")
b1<-bootdist(f1)
print(b1)
plot(b1)
summary(b1)

b1b<-bootdist(f1,bootmethod="nonparam")
summary(b1b)

f1b<-fitdist(x1,"gamma",method="mle")
b1b<-bootdist(f1b)
plot(b1b)

x2<-c(rep(4,1),rep(2,3),rep(1,7),rep(0,12))
f2<-fitdist(x2,"pois",method="mom")
b2<-bootdist(f2)
plot(b2,pch=16)
summary(b2)




