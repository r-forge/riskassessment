### Name: dimmcnode
### Title: Dimension of mcnode and mc Objects
### Aliases: dimmcnode dimmc
### Keywords: utilities

### ** Examples

data(total)
dimmcnode(xVUM2)
dimmc(total)




