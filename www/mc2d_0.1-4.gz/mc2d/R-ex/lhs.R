### Name: lhs
### Title: Random Latin Hypercube Sampling
### Aliases: lhs
### Keywords: design

### ** Examples

ceiling(lhs(runif, nsu=10, nsv=10)*10)



