### Name: typemcnode
### Title: Provides the Type of a mcnode Object
### Aliases: typemcnode
### Keywords: utilities

### ** Examples

data(total)
typemcnode(total$xVUM2)



