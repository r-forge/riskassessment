### Name: is.mc
### Title: Tests mc and mcnode Objects
### Aliases: is.mc is.mcnode
### Keywords: utilities

### ** Examples

data(total)
is.mcnode(xVU)
is.mcnode(total)
is.mc(total)




