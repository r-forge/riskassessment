### Name: quantile.mc
### Title: Quantiles of a mc Object
### Aliases: quantile.mc quantile.mcnode
### Keywords: univar

### ** Examples

data(total)
quantile(total$xVUM3)
quantile(total)




