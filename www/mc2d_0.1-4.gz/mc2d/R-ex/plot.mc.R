### Name: plot.mc
### Title: Plots Results of a Monte Carlo Simulation
### Aliases: plot.mc plot.mcnode plot.plotmc plot.mccut
### Keywords: hplot

### ** Examples

data(total)
plot(xVUM3)
plot(total)





