### Name: outm
### Title: Output of Nodes
### Aliases: outm
### Keywords: misc

### ** Examples

data(total)
total$xVUM2
## since outm = NULL
summary(total$xVUM2) 
x <- outm(total$xVUM2, c("min"))
summary(x)



