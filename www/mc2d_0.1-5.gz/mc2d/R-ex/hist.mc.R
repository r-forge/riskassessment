### Name: hist.mc
### Title: Histogram of a Monte Carlo Simulation
### Aliases: hist.mc hist.mcnode
### Keywords: hplot

### ** Examples

data(total)
hist(xVUM3)
hist(total)




