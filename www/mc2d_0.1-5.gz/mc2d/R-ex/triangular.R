### Name: triangular
### Title: The Triangular Distribution
### Aliases: triangular dtriang ptriang qtriang rtriang
### Keywords: distribution

### ** Examples

curve(dtriang(x, min=3, mode=5, max=10), from = 2, to = 11)





