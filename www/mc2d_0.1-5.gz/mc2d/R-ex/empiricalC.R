### Name: empiricalC
### Title: The Continuous Empirical Distribution
### Aliases: empiricalC dempiricalC pempiricalC qempiricalC rempiricalC
### Keywords: distribution

### ** Examples

prob <- c(2, 3, 1, 6, 1)
values <- 1:5
par(mfrow=c(1, 2))
curve(dempiricalC(x, min=0, max=6, values, prob), from=-1, to=7, n=1001)
curve(pempiricalC(x, min=0, max=6, values, prob), from=-1, to=7, n=1001)





