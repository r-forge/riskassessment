### Name: rtrunc
### Title: Random Truncated Distributions
### Aliases: rtrunc
### Keywords: distribution

### ** Examples

rtrunc("rnorm", n=10, linf=0)
range(rtrunc(rnorm, n=1000, linf=3, lsup=5, sd=10))



