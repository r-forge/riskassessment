### Name: summary.mc
### Title: Summary of mcnode and mc Object
### Aliases: summary.mc summary.mcnode print.summary.mc summary.mccut
### Keywords: univar

### ** Examples

data(total)
summary(xVUM3)
summary(total)





